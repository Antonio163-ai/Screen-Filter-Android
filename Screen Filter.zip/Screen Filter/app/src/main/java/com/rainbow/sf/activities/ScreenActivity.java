package com.rainbow.sf.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import com.rainbow.sf.R;
import android.widget.SeekBar;
import android.widget.ToggleButton;
import com.rainbow.sf.activities.filters.FilterMemory;
import com.rainbow.sf.activities.services.ScreenFilterService;
import android.content.Intent;
import android.view.View;
import android.os.CountDownTimer;
import android.support.v7.widget.Toolbar;
import android.support.v4.widget.DrawerLayout;
import android.support.design.widget.NavigationView;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import com.rainbow.sf.activities.fragments.FilterFragment;
import android.support.v4.view.GravityCompat;
import android.view.Gravity;
import com.rainbow.sf.activities.fragments.SettingsFragment;
import android.support.v7.preference.PreferenceFragmentCompat;
import android.content.SharedPreferences;
import android.support.v7.preference.PreferenceManager;


public class ScreenActivity extends AppCompatActivity implements SharedPreferences.OnSharedPreferenceChangeListener {

	Toolbar toolbar;
	DrawerLayout drawer;
	NavigationView navView;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
		PreferenceManager.getDefaultSharedPreferences(getBaseContext()).registerOnSharedPreferenceChangeListener(this);
		setThemeOfApp();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_activity);
		
		toolbar = findViewById(R.id.main_toolbar_home);
		drawer = findViewById(R.id.drawer);
		navView = findViewById(R.id.nav_view);
		setSupportActionBar(toolbar);
		
		
		ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawer,toolbar,R.string.drawer_open,R.string.drawer_close);

		drawer.addDrawerListener(toggle);
		toggle.syncState();
		getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new FilterFragment()).commit();
		navView.setCheckedItem(R.id.nav_home);
		
		
		navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener(){

				@Override
				public boolean onNavigationItemSelected(MenuItem item) {
					switch(item.getItemId()){
						case R.id.nav_home:
							getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new FilterFragment()).commit();
						break;
						case R.id.nav_settings:
							getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new BaseSettingsFragment()).commit();
						break;
						}
						drawer.closeDrawer(GravityCompat.START);
					    return true;
						}
						});
	}
	@Override
	public void onSharedPreferenceChanged(SharedPreferences p1, String p2) {
		if(p2.equals("themes")){
			this.recreate();
		}
	}
	
	@Override
	public void onBackPressed() {
		if(drawer.isDrawerOpen(Gravity.START)){
			drawer.closeDrawer(Gravity.START);
		}else{
		super.onBackPressed();
		}
	}
	public static class BaseSettingsFragment extends PreferenceFragmentCompat {


		@Override
		public void onCreatePreferences(Bundle p1, String p2) {
			setPreferencesFromResource(R.xml.settings_preferences,p2);
		}
	}
	private void setThemeOfApp(){
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
		
		if(sp.getString("themes","Dark").equals("Dark")){
			setTheme(R.style.AppTheme);
			//toolbar.setBackgroundColor(R.color.toolbar);
		}else{
			setTheme(R.style.AppThemeV2);
			//toolbar.setBackgroundColor(R.color.toolbar2);
		}
	}
}
