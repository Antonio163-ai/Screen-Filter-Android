package com.rainbow.sf.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import com.rainbow.sf.R;
import android.support.v7.preference.PreferenceFragmentCompat;

public class SettingsActivity extends AppCompatActivity {
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
    }
	public class SettingsFragment extends PreferenceFragmentCompat {


		@Override
		public void onCreatePreferences(Bundle p1, String p2) {
			setPreferencesFromResource(R.xml.settings_preferences,p2);
		}


	}
}
