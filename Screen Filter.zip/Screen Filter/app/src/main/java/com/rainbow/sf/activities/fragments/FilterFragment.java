package com.rainbow.sf.activities.fragments;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.rainbow.sf.R;
import android.widget.SeekBar;
import android.widget.ToggleButton;
import com.rainbow.sf.activities.filters.FilterMemory;
import android.os.CountDownTimer;
import com.rainbow.sf.activities.services.ScreenFilterService;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import com.rainbow.sf.activities.services.NotificationService;
public class FilterFragment extends Fragment
{
	View v;
	SeekBar alpha,red,green,blue;
	
	FilterMemory fm;
	CountDownTimer mCountDownTime;
	FloatingActionButton fab;
	boolean isStart = false;
	
	public FilterFragment(){
		
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		v = inflater.inflate(R.layout.filter_fragments,container,false);
		
		filter();
		
		return v;
		}
	private void filter(){
		alpha = v.findViewById(R.id.filter_alpha);
		red = v.findViewById(R.id.filter_red);
		green = v.findViewById(R.id.filter_green);
		blue = v.findViewById(R.id.filter_blue);
		fab = v.findViewById(R.id.fab_startStopService);
		
		
		fm = new FilterMemory(getContext());

		alpha.setMax(200);
		red.setMax(190);
		green.setMax(200);
		blue.setMax(200);

	    alpha.setProgress(fm.getAlpha());
		red.setProgress(fm.getRed());
		blue.setProgress(fm.getBlue());
		green.setProgress(fm.getGreen());
		
		SeekBar.OnSeekBarChangeListener changeListener = new SeekBar.OnSeekBarChangeListener(){

			@Override
			public void onProgressChanged(SeekBar Seekbar, int progress, boolean fromUser) {
				fm.setAlpha(alpha.getProgress());
				fm.setRed(red.getProgress());
				fm.setGreen(green.getProgress());
				fm.setBlue(blue.getProgress());

				if(ScreenFilterService.STATE == ScreenFilterService.STATE_ACTIVE){
					Intent intent = new Intent(getContext(),ScreenFilterService.class);
					getContext().startService(intent);
				}
				
				//startFilter.setChecked(ScreenFilterService.STATE == ScreenFilterService.STATE_ACTIVE);
			}

			@Override
			public void onStartTrackingTouch(SeekBar seek) {

			}

			@Override
			public void onStopTrackingTouch(SeekBar seek) {

			}
		};

		alpha.setOnSeekBarChangeListener(changeListener);
		red.setOnSeekBarChangeListener(changeListener);
		green.setOnSeekBarChangeListener(changeListener);
		blue.setOnSeekBarChangeListener(changeListener);

		fabPresed();
		}
		private void fabPresed(){
			fab.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View p1) {
						Intent n = new Intent(getContext(),NotificationService.class);
						Intent i = new Intent(getContext(),ScreenFilterService.class);
						if(ScreenFilterService.STATE == ScreenFilterService.STATE_ACTIVE){
							fab.setImageResource(R.drawable.ic_play);
							getContext().stopService(i);
							getContext().stopService(n);
						}else{
							fab.setImageResource(R.drawable.ic_pause);
							getContext().startService(i);
							getContext().startService(n);
						}
						refresh();
					}
			});
		}
		
	private void refresh(){
		if(mCountDownTime != null){
			mCountDownTime.cancel();

			mCountDownTime = new CountDownTimer(100,100){

				@Override
				public void onTick(long p1) {

				}

				@Override
				public void onFinish() {
					
				}


			};
			mCountDownTime.start();
		}
	}
	
}
