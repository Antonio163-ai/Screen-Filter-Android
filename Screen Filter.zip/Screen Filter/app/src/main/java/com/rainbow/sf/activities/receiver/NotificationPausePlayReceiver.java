package com.rainbow.sf.activities.receiver;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.Context;
import com.rainbow.sf.activities.services.NotificationService;
import android.widget.Toast;
import com.rainbow.sf.activities.services.ScreenFilterService;
import com.rainbow.sf.activities.ScreenActivity;

public class NotificationPausePlayReceiver extends BroadcastReceiver
{
	
@Override
	public void onReceive(Context p1, Intent p2) {
		Intent i = new Intent(p1,ScreenFilterService.class);
		Intent n = new Intent(p1,NotificationService.class);
		if(ScreenFilterService.STATE == ScreenFilterService.STATE_ACTIVE){
			p1.stopService(i);
			}else{
			p1.startService(i);
			}
			p1.startService(n);
	}

}
